struct export_list_t {
    char * name;
    void * pointer;
} export_list[] = {
    { 0, 0 }
};
