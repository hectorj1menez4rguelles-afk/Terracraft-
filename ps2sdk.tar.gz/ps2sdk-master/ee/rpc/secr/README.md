# Security manager RPC client

Remote procedure call client for the secrman module.  

Requires secrsif IOP module to be loaded.  

The source code for this module is based upon the source code from FMCB Installer v0.987.  
