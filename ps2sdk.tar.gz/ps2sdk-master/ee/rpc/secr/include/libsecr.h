#ifndef LIBSECR_H
#define LIBSECR_H

#include <libsecr-common.h>

extern int SecrInit(void);
extern void SecrDeinit(void);

#endif
