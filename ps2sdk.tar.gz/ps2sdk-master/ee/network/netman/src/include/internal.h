extern void NetManToggleGlobalNetIFLinkState(unsigned char state);
extern void NetManUpdateStackNIFLinkState(void);
