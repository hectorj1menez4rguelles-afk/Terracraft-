extern int NetManInitRPCServer(void);
extern void NetManDeinitRPCServer(void);
extern int NetManRPCAllocRxBuffers(void);
