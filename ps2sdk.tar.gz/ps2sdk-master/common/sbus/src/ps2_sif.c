/*

Common PS2 SIF management API for both EE and IOP.

This file contains all common code for both EE and IOP SIF management.

*/

#include <tamtypes.h>
#include <ps2_reg_defs.h>
#include "ps2_sbus.h"
#include "sbus_priv.h"
