PlayStation 2 SDK - External dependencies
------------------------------------------------------------

Inside of this folder during `make` process it will download by using `git clone` some dependencies, common for `IOP` and `EE`.

Dependencies:
*   lwip ps2-v2.0.3
*   FatFS iop-r0.15