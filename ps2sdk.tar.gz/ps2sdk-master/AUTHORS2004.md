﻿```text
_____     ___ ____     ___ ____
 ____|   |    ____|   |        | |____|
|     ___|   |____ ___|    ____| |    \    PS2DEV Open Source Project.
----------------------------------------------------------------------
Copyright 2001-2004.
Licensed under Academic Free License version 2.0
Review ps2sdk README & LICENSE files for further details.
```

The following people have contributed to the ps2sdk project:

NOTE: If your name is not in the list below and you have contributed to this project, please add your details to this file if you have write access to the CVS. If you do not have write access to the CVS, please contact David Ryan.

Alias    | Real Name         | Github profile or e-mail
---------|-------------------|---------------------
 csh     | Gustavo Scotti    | gustavo@scotti.com
 Oobles  | David Ryan        | [oobles](https://github.com/oobles)
 Sjeep   | Nicholas Van Veen | nickvv@xtra.co.nz
 Pukko   | N/A               | N/A
 Karmix  | Doug Knight       | fsdck@uaf.edu
 adresd  | ???               | adresd_ps2dev@yahoo.com
 mrbrown | Marcus R. Brown   | [mrbrown](https://github.com/marcusrbrown)
 loser   | N/A               | [x0rloser](https://github.com/x0rloser)
 TyRaNiD | That Guy          | [tyranid](https://github.com/tyranid)
 ooPo    | Naomi Peori       | [ooPo](https://github.com/ooPo)
 gawd    | Gil Megidish      | [gmegidish](https://github.com/gmegidish)
 pixel   | Nicolas Noble     | [nicolasnoble](https://github.com/nicolasnoble)

.. and many others from the ps2dev community for feedback and fixes :)
